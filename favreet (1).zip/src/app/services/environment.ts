export const environments = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDfbWYJgUsathX6nRxUnQ3iQ-zVmA4VdqY",
  	authDomain: "favreet-b2e1c.firebaseapp.com",
  	databaseURL: "https://favreet-b2e1c.firebaseio.com",
  	projectId: "favreet-b2e1c",
  	storageBucket: "favreet-b2e1c.appspot.com",
  	messagingSenderId: "203628444258",
  	appId: "1:203628444258:android:aa418d18aa6687561f2f3b"
  }
};