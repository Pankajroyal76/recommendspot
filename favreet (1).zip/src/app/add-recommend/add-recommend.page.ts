import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-recommend',
  templateUrl: './add-recommend.page.html',
  styleUrls: ['./add-recommend.page.scss'],
})
export class AddRecommendPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
