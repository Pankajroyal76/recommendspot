import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-localrecommenddetail',
  templateUrl: './localrecommenddetail.page.html',
  styleUrls: ['./localrecommenddetail.page.scss'],
})
export class LocalrecommenddetailPage implements OnInit {
hideMe2=false;
hide2() {
this.hideMe2 = !this.hideMe2;
}
  constructor() { }

  ngOnInit() {
  }

}
