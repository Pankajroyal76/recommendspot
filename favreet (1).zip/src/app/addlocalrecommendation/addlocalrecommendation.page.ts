import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addlocalrecommendation',
  templateUrl: './addlocalrecommendation.page.html',
  styleUrls: ['./addlocalrecommendation.page.scss'],
})
export class AddlocalrecommendationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
