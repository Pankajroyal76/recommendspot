import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddlocalrecommendationPageRoutingModule } from './addlocalrecommendation-routing.module';

import { AddlocalrecommendationPage } from './addlocalrecommendation.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddlocalrecommendationPageRoutingModule
  ],
  declarations: [AddlocalrecommendationPage]
})
export class AddlocalrecommendationPageModule {}
